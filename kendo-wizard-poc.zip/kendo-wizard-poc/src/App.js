import logo from './logo.svg';
import './App.css';
import Kendowizard from "./Wizard/SampleWizard";
function App() {
  return (
    <div className="App">
     <Kendowizard></Kendowizard>
     
    </div>
  );
}

export default App;
