import * as React from 'react';



export const PaymentDetails = () => (
    <div>
        <label>Final Page</label>
        <label>Hello</label>
    </div>
);